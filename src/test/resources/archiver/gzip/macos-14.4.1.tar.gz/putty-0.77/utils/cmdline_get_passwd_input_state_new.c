/*
 * A preinitialised cmdline_get_passwd_input_state which makes it easy
 * to assign by structure copy.
 */

#include "putty.h"

const cmdline_get_passwd_input_state cmdline_get_passwd_input_state_new =
    CMDLINE_GET_PASSWD_INPUT_STATE_INIT;
