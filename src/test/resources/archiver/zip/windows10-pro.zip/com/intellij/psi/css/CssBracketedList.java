package com.intellij.psi.css;

public interface CssBracketedList extends CssTerm, CssLineNames {
}
