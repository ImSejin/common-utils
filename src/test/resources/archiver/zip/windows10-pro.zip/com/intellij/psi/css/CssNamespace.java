package com.intellij.psi.css;

public interface CssNamespace extends CssAtRule {
  CssNamespace[] EMPTY_ARRAY = new CssNamespace[0];
  
  String getPrefix();
  String getUri();
}
