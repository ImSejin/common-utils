package com.intellij.psi.css;

public interface CssSelectorSuffixList extends CssElement {
}
